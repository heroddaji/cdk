package daichuanthar.websocketclient;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.util.ArrayMap;
import android.util.Log;
import android.widget.Toast;

import com.koushikdutta.async.http.AsyncHttpClient;
import com.koushikdutta.async.http.socketio.Acknowledge;
import com.koushikdutta.async.http.socketio.ConnectCallback;
import com.koushikdutta.async.http.socketio.EventCallback;
import com.koushikdutta.async.http.socketio.SocketIOClient;

public class SocketIOSingleton extends Activity {
	String tag = "SocketIOSingleton";
	private static SocketIOSingleton instance = null;

	SocketIOClient socketIOClient = null;
	String serverAddress = "http://163.180.116.93:2013";
	List<String> users = new ArrayList<String>();
	boolean hasNewUser = false;
	boolean hasNewMessage = false;
	String username = "unknown";
	List<String> chat = new ArrayList<String>();

	protected SocketIOSingleton() {
		init();
	}

	public static SocketIOSingleton getInstance() {
		if (instance == null) {
			instance = new SocketIOSingleton();
		}
		return instance;
	}

	public void sendEvent(String event, String value) {
		if (socketIOClient == null) {
			Log.e(tag, "socketioclient is null");
			Toast.makeText(getApplicationContext(), "socketioclient is null",
					Toast.LENGTH_LONG).show();
		}
		try {

			JSONArray args = new JSONArray();

			if (event.equals("user register")) {
				JSONObject obj = new JSONObject();
				obj.put("username", value);
				args.put(obj);
				this.username = value;
			}

			if (event.equals("message")) {
				JSONObject obj = new JSONObject();
				obj.put("time", "16:20:10");
				obj.put("username", username);
				obj.put("messages", value);
				args.put(obj);			
			}

			socketIOClient.emit(event, args);

		} catch (Exception e) {
			Log.e(tag, e.getLocalizedMessage());
			Toast.makeText(getApplicationContext(), e.getLocalizedMessage(),
					Toast.LENGTH_LONG).show();
		}
	}

	private void init() {

		SocketIOClient.connect(AsyncHttpClient.getDefaultInstance(),
				serverAddress, new ConnectCallback() {

					@Override
					public void onConnectCompleted(Exception e,
							SocketIOClient client) {

						if (e != null) {
							Log.e(tag, e.getLocalizedMessage());
							Toast.makeText(getApplicationContext(),
									"No internet", Toast.LENGTH_LONG).show();
						}

						socketIOClient = client;

						client.on("user joined", new EventCallback() {
							@Override
							public void onEvent(JSONArray data, Acknowledge ack) {
								setUsersFromServer(data);
								hasNewUser = true;
							}
						});
						

						client.on("message success", new EventCallback() {

							@Override
							public void onEvent(JSONArray args, Acknowledge arg1) {
								Log.d(tag, args.toString());
								setChatMessage(args);
								hasNewMessage = true;
							}
						});

					}
				});
	}

	private void setChatMessage(JSONArray data) {
		try {
			JSONArray array = data.getJSONArray(0);
			JSONObject obj = array.getJSONObject(array.length()-1);
			Map<String,Object> chatMsg = JsonHelper.toMap(obj);
			String username = (String) chatMsg.get("username");
			String messages = (String) chatMsg.get("messages");
			String time = (String) chatMsg.get("time");
			
			String result = username + ": "+ messages; 
			
			chat.add(result);

		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setUsersFromServer(JSONArray data) {
		try {
			if (data != null) {
				users = new ArrayList<String>();
				JSONArray array = data.getJSONArray(0);
				int len = array.length();
				for (int i = 0; i < len; i++) {
					JSONObject obj = array.getJSONObject(i);
					users.add((String) obj.get("username"));
				}

			}

		} catch (JSONException e) {
			Log.e(tag, e.getLocalizedMessage());
			Toast.makeText(getApplicationContext(), e.getLocalizedMessage(),
					Toast.LENGTH_LONG).show();
		}

	}

	public List<String> getUsers() {
		return users;

	}

	public boolean hasNewUser() {
		return hasNewUser;
	}

	public void setNoNewUser() {
		hasNewUser = false;
	}

	public String getUsername() {
		return username;
	}
	

	public List<String> getChat() {
		return chat;
	}

	public boolean isHasNewMessage() {
		return hasNewMessage;
	}

	public void setHasNewMessage(boolean hasNewMessage) {
		this.hasNewMessage = hasNewMessage;
	}

}
