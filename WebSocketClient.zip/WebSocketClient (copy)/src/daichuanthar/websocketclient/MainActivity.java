package daichuanthar.websocketclient;

import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import daichuanthar.webrtcclient.R;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends FragmentActivity implements ActionBar.TabListener {

	static Context context;

	private static final String TAG = "MainActivity";
	public final static String EXTRA_MESSAGE = "MainActivity.MESSAGE";

	static ArrayAdapter usersAdapter = null;
	static ArrayAdapter chatAdapter = null;
	static AppSectionsPagerAdapter mAppSectionsPagerAdapter;
	ViewPager mViewPager;
	final Handler myHandler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		SocketIOSingleton.getInstance();
		mAppSectionsPagerAdapter = new AppSectionsPagerAdapter(getSupportFragmentManager());

		final ActionBar actionBar = getActionBar();
		actionBar.setNavigationMode(actionBar.NAVIGATION_MODE_TABS);

		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mAppSectionsPagerAdapter);
		mViewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
			@Override
			public void onPageSelected(int position) {
				actionBar.setSelectedNavigationItem(position);
			}
		});

		for (int i = 0; i < mAppSectionsPagerAdapter.getCount(); i++) {
			actionBar.addTab(actionBar.newTab().setText(mAppSectionsPagerAdapter.getPageTitle(i)).setTabListener(this));
		}

		// timer
		Timer myTimer = new Timer();
		myTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				UpdateGUIUserList();
			}
		}, 0, 1000);

	}

	private void UpdateGUIUserList() {
		myHandler.post(myRunnable);

	}

	final Runnable myRunnable = new Runnable() {
		public void run() {
			if (SocketIOSingleton.getInstance().hasNewUser() == true) {
				// adapter.clear();
				usersAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, SocketIOSingleton.getInstance().getUsers());
				// adapter.notifyDataSetChanged();
				ListView listview = (ListView) findViewById(R.id.listViewUsers);
				listview.setAdapter(usersAdapter);
				listview.invalidateViews();
				SocketIOSingleton.getInstance().setNoNewUser();
			}
			
			if (SocketIOSingleton.getInstance().isHasNewMessage() == true) {
				chatAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1,SocketIOSingleton.getInstance().getChat()); 
				ListView listview = (ListView) findViewById(R.id.listViewChat);
				listview.setAdapter(chatAdapter);
				listview.invalidateViews();
				SocketIOSingleton.getInstance().setHasNewMessage(false);
			}

		}
	};

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onTabSelected(Tab tab, FragmentTransaction ft) {
		mViewPager.setCurrentItem(tab.getPosition());
		Log.i(TAG, "onTabSelected");

		UpdateGUIUserList();

	}

	@Override
	public void onTabUnselected(Tab tab, FragmentTransaction ft) {
		Log.i(TAG, "onTabUnselected");
	}

	@Override
	public void onTabReselected(Tab tab, FragmentTransaction ft) {
		Log.i(TAG, "onTabReselected");
	}

	public static class AppSectionsPagerAdapter extends FragmentPagerAdapter {

		public AppSectionsPagerAdapter(FragmentManager fm) {
			super(fm);

		}

		@Override
		public Fragment getItem(int i) {

			switch (i) {
			case 0:
				return new RegisterFragment();
			case 1:
				return new UserFragment();
			case 2:
				return new RoomFragment();
			default:
				// The other sections of the app are dummy placeholders.
				Fragment fragment = new UserFragment();
				Bundle args = new Bundle();
				args.putInt(UserFragment.ARG_SECTION_NUMBER, i + 1);
				fragment.setArguments(args);
				return fragment;
			}
		}

		@Override
		public int getCount() {

			return 3;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			switch (position) {
			case 0:
				return "Register";
			case 1:
				return "Users";
			default:
				return "Lobby";
			}
		}

	}

	public static class RegisterFragment extends Fragment {
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_register, container, false);

			final EditText text = (EditText) rootView.findViewById(R.id.editTextRegister);

			rootView.findViewById(R.id.buttonRegister).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					String username = text.getText().toString();
					SocketIOSingleton.getInstance().sendEvent("user register", username);
					Toast.makeText(getActivity(), "You have registered", Toast.LENGTH_LONG).show();

				}
			});

			rootView.findViewById(R.id.buttonBug).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					int a = 1 / 0;
				}
			});
			return rootView;
		}
	}

	public static class RoomFragment extends Fragment {
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			final View rootView = inflater.inflate(R.layout.fragment_room, container,
					false);
			context = rootView.getContext();
			chatAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1,SocketIOSingleton.getInstance().getChat());

			final EditText chatEText = (EditText) rootView.findViewById(R.id.editTextChat);
			
			
			final ListView listview = (ListView) rootView
					.findViewById(R.id.listViewChat);
			listview.setAdapter(chatAdapter);
			
			Button sendButton = (Button) rootView.findViewById(R.id.buttonChat);
			sendButton.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					String msg = chatEText.getText().toString();
					SocketIOSingleton.getInstance().sendEvent("message",msg);					
				}
			});
		
			return rootView;
		}
	}

	public static class UserFragment extends Fragment {

		public static final String ARG_SECTION_NUMBER = "section_number";

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			final View rootView = inflater.inflate(R.layout.fragment_user, container, false);
			context = rootView.getContext();
			usersAdapter = new ArrayAdapter<String>(rootView.getContext(), android.R.layout.simple_list_item_1, SocketIOSingleton.getInstance().getUsers());

			final ListView listview = (ListView) rootView.findViewById(R.id.listViewUsers);
			listview.setAdapter(usersAdapter);
			listview.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					Toast.makeText(rootView.getContext(), "Click ListItem Number " + position, Toast.LENGTH_LONG).show();
					String clickItem = listview.getItemAtPosition(position).toString();

				}
			});
			return rootView;
		}

		@Override
		public void onStart() {
			super.onStart();

			if (usersAdapter == null)
				return;

			usersAdapter.notifyDataSetChanged();
		}

		@Override
		public void onResume() {
			super.onResume();
			Log.i(TAG, "onResume");
		}

		@Override
		public void onPause() {
			super.onPause();
			Log.i(TAG, "onPause");
		}

		@Override
		public void onStop() {
			super.onStop();
			Log.i(TAG, "onStop");
		}

		// ////////////////////////////////////////////////////////////////////////////
		// Called during the life cycle, when instance state should be
		// saved/restored
		// ////////////////////////////////////////////////////////////////////////////

		@Override
		public void onSaveInstanceState(Bundle toSave) {
			super.onSaveInstanceState(toSave);
			Log.i(TAG, "onSaveinstanceState");
		}

	}

}
