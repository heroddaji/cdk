/** Automatically generated file. DO NOT MODIFY */
package daichuanthar.webrtcclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}