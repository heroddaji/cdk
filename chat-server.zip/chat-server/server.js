var static = require('node-static');
var http = require('http')
var file = new(static.Server)();
var times = 0;


 var app = http.createServer(function (req, res) {
  file.serve(req, res);
}).listen(2013);


var io = require('socket.io').listen(app);
io.set('log level', 1);
var numUsers = 0;
var usernames = new Array();
var messages = new Array();
var currentUser = 'guest';
io.sockets.on('connection', function (socket){
  var addedUser = false;
  var jsonArray = [];  
  
  socket.on('user register', function(data){	  	  
		var user = data.username;		
		if(hasId(usernames,user)){
			console.log('existing user');
		}else{
			addedUser = true;
			numUsers++;
			
			usernames.push(data);
			currentUser = user;
			//console.log('new user:' + user);
			socket.username = user;			
						
			jsonArray = JSON.parse(JSON.stringify(usernames));
			io.sockets.emit('user joined', jsonArray);
		}		
	
  });	

socket.on('message', function(data){	
			messages.push(data);			
						
			jsonArray = JSON.parse(JSON.stringify(messages));
			io.sockets.emit('message success', jsonArray);
	
  });
  
  socket.on('join room',function(roomjson){
	  console.log('join room:' + roomjson.room);
	  socket.room = roomjson.room;	
	  socket.join(roomjson.room);
  });  

  
  socket.on('disconnect', function () {
    if (addedUser) {
	  	 console.log('user left:' + currentUser);
		var index = usernames.indexOf(currentUser);
		if (index > -1) {
			usernames.splice(index, 1);
		}
		--numUsers;
		console.log('remaining users:'+ usernames.length);
		
    }
  });

});

function hasId(data, id) {
  return data.some(function (el) {
    return el.username === id;
  });
}
