// JavaScript Document
var cookieOptions = {path : '/'};
var i = 0;

window.onbeforeunload = function(){
   console.log("close");
}

$(function() {	
	$( "#dialog" ).dialog({
		modal: true,
		draggable: true,
		resizable: false,
		position: ['center', 'center'],
		show: 'blind',
		hide: 'blind',
		width: 310,
		dialogClass: 'ui-dialog-osx',
		buttons: {			
			"Cancel": function() {
				$(this).dialog("close");
			},
			"Register": function() {
				//$.cookies.set("username", $("#name").val(), cookieOptions);
				$('#username').val($("#name").val());
				var date = new Date();
				var time = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
				var user = { username : $("#name").val(), time : time};
				socket.emit('user register', user);
				$(this).dialog("close");
			}
		}	
	});

	$('form').submit(function(){
		var username = $('#username').val();//$.cookies.get("username");
		if(username == null || username == ''){
			username = "Guest";
		}
		var date = new Date();
		var time = date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
		var usertemp = { username : username, messages : $("#m").val(), time : time};
		//alert(JSON.stringify(usertemp));
        	socket.emit('message', usertemp);
        	$('#m').val('');
		$( "#m" ).focus();
        	return false;
      });	
});	
socket.on('message success', function(msgs){
	var html = '';
	//for(var i in msgs){
		var msg = msgs[msgs.length - 1];
		//console.log(msg);
		var username = msg.username;
		var messages = msg.messages;
		var time = msg.time;
		html += '<div class="chat">';
		html += '<div class="message';
		if(i % 2 == 0)
			html += ' grayBg';
		html += '">';
		html += '<a class="user" href="#">' + username + ':</a> ';
		html += messages;
		html += '</div>';
		html += '<div class="time';
		if(i % 2 == 0)
			html += ' grayBg';
		html += '">'
		html += time;
		html += '</div>';
		html += '</div>';
	//}
	i++;
        $('.content').append(html);
	$container = $('.content');
    	$container.animate({ scrollTop: $container[0].scrollHeight }, "slow");
});
socket.on('user joined', function(users){
	var user = '';
	var username = '';
	var time = '';
	var html = '';
	console.log(users);
	for(var j in users){	
		user = users[j];
if(user != null){
		username = user.username;
		time = user.time;
		html += '<div class="user';
		if(j % 2 == 0)
			html += ' grayBg';
		html += '">';
		html += '<img src="imgs/user.png" height="18" class="floatleft" />';
		html += username ;
		html += '</div>';
}
	}
	$('#list_friend').html(html);
	html = '';
	//for(var i in msgs){
		
		html += '<div class="chat">';
		html += '<div class="message';
		if(i % 2 == 0)
			html += ' grayBg';
		html += '">';
		html += '<a class="user" href="#">' + 'SYSTEM' + ':</a> ';
		html += username + ' joined';
		html += '</div>';
		html += '<div class="time';
		if(i % 2 == 0)
			html += ' grayBg';
		html += '">'
		html += time;
		html += '</div>';
		html += '</div>';
	//}
	i++;
        $('.content').append(html);
        $('#right').find('#title').html('Participants(' + users.length + ')');
	$container = $('#list_friend');
    	$container.animate({ scrollTop: $container[0].scrollHeight }, "slow");
	$container = $('.content');
    	$container.animate({ scrollTop: $container[0].scrollHeight }, "slow");
});  
