
console.log('hello');
var socket = io.connect('/');



     
