// JavaScript Document
$(function() {	
	$( "#dialog" ).dialog({
		modal: true,
		draggable: true,
		resizable: false,
		position: ['center', 'center'],
		show: 'blind',
		hide: 'blind',
		width: 310,
		dialogClass: 'ui-dialog-osx',
		buttons: {			
			"Cancel": function() {
				$(this).dialog("close");
			},
			"Register": function() {
				var user = {"username": $("#name").val()};		
				socket.emit('user register', user);
				$(this).dialog("close");
			}
		}	
	});	
	$('#btn_send').on('click', function(){
		
	});	
});
socket.on('user joined', function(msg){
	var name = JSON.stringify(msg);
    $('#messages').append($('<li>').text(name));
});